<html>
<head>
      <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
      <title>TABELA</title>
</head>
<body>
<center>
<h2>  Tabela: </h2>
<br>
<?php
$szerokosc=300;
$wysokosc=200;
//$n=5; //przy malym $n zawiesza sie
$n=5; //przy malym $n zawiesza sie
$r=$wysokosc/$n;
$s=$szerokosc/$n;
//$cykle=80;
$cykle=90;
//$cykle=400; juz za duzo
//echo($r."  ".$s);
//echo("<br>");
for ($i=0;$i<=$r+1;$i++)
	{
	for ($j=0;$j<=$s+1;$j++)
		{$tabela1[$i][$j]=0;
  		 $tabela2[$i][$j]=0;
		}
	}
include("data.php");
$poczet=count($pocz)/2;
for ($i=1;$i<=$poczet;$i++)
	{ 
	 $i1=$pocz[2*$i-2]; 
	 $i2=$pocz[2*$i-1];
	 $tabela1[$i1][$i2]=1;
	}	
for ($krok=1;$krok<=$cykle;$krok++){	
echo("<table border bordercolor=black rules=all width=".$szerokosc." height=".$wysokosc.">");
//	echo("<tr><td ></td><td></td></tr>"); 
for ($i=1;$i<=$r;$i++)
	{
	echo("<tr>");
	for ($j=1;$j<=$s;$j++)
	   	if ($tabela1[$i][$j]==1)
		echo("<td bgcolor='Black'></td>");
		else echo("<td></td>");
	echo("</tr>");
	}
echo("</table> ");
  for ($i=1;$i<=$r;$i++)
	{
	for ($j=1;$j<=$s;$j++)
		{$suma=$tabela1[$i-1][$j-1]+$tabela1[$i-1][$j]+$tabela1[$i-1][$j+1]+
		$tabela1[$i][$j-1]+$tabela1[$i][$j+1]+
		$tabela1[$i+1][$j-1]+$tabela1[$i+1][$j]+$tabela1[$i+1][$j+1];
		if ($suma==3)
			{
  			$tabela2[$i][$j]=1;
   			}
  			else {if ($suma==2)
			   	{
    				$tabela2[$i][$j]=$tabela1[$i][$j];
		     		}	
  			  	else $tabela2[$i][$j]=0;
			     }
	     		
		}
	}
echo("KONIEC TABELKI ".$krok);	
for ($i=1;$i<=$r;$i++)
	{
	for ($j=1;$j<=$s;$j++)
		{$tabela1[$i][$j]=$tabela2[$i][$j];
		}
	} 
}
?>
</center>
</body>
</html>
